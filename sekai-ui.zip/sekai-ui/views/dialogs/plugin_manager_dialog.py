from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QLabel,
    QMessageBox,
)

from parsers.api import list_parsers, install_or_update_repo, remove_external_parser


class PluginManagerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Gerenciador de Extensões")
        self.resize(680, 420)

        self._info_label = QLabel("")
        self._list = QListWidget()

        self._btn_repo = QPushButton("Baixar/Atualizar repositório")
        self._btn_remove = QPushButton("Remover extensão selecionada")
        self._btn_close = QPushButton("Fechar")

        self._btn_repo.clicked.connect(self._install_from_repo)
        self._btn_remove.clicked.connect(self._remove_selected)
        self._btn_close.clicked.connect(self.accept)

        root = QVBoxLayout(self)
        root.addWidget(self._info_label)
        root.addWidget(self._list, 1)

        row = QHBoxLayout()
        row.addWidget(self._btn_repo)
        row.addWidget(self._btn_remove)
        row.addStretch(1)
        row.addWidget(self._btn_close)
        root.addLayout(row)

        self._reload_parsers_list()

        try:
            info = list_parsers()
            if not bool(info.get("repo_installed", True)):
                res = QMessageBox.question(
                    self,
                    "Extensões",
                    "O repositório de extensões ainda não foi instalado.\n\n"
                    "Deseja baixar agora?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.Yes,
                )
                if res == QMessageBox.Yes:
                    self._install_from_repo()
        except Exception:
            pass


    def _reload_parsers_list(self) -> None:
        self._list.clear()

        info = list_parsers()
        repo_ok = bool(info.get("repo_installed", False))

        installed = info.get("installed") or []
        external = info.get("external") or []

        self._info_label.setText(
            "Repositório: " + ("instalado" if repo_ok else "não instalado") +
            f" | Parsers: {len(installed)} (externos: {len(external)})"
        )

        # Ordena por nome
        installed_sorted = sorted(installed, key=lambda p: (p.get("name") or "").lower())

        for p in installed_sorted:
            pid = p.get("id") or ""
            name = p.get("name") or pid or "(sem nome)"
            exts = p.get("extensions") or []

            is_ext = pid in set(external)
            tag = "Extensão" if is_ext else "Interno"

            label = f"{name}  ({', '.join(exts)})  — {tag}"
            it = QListWidgetItem(label)
            it.setData(Qt.UserRole, pid)
            it.setData(Qt.UserRole + 1, is_ext)
            self._list.addItem(it)

        self._btn_remove.setEnabled(any(self._list.item(i).data(Qt.UserRole + 1) for i in range(self._list.count())))

    def _install_from_repo(self) -> None:
        try:
            install_or_update_repo()
            QMessageBox.information(self, "Extensões", "Repositório atualizado com sucesso.")
        except Exception as e:
            QMessageBox.critical(self, "Extensões", f"Falha ao atualizar repositório:\n\n{e}")
        self._reload_parsers_list()

    def _remove_selected(self) -> None:
        it = self._list.currentItem()
        if not it:
            return

        pid = it.data(Qt.UserRole) or ""
        is_ext = bool(it.data(Qt.UserRole + 1))
        if not is_ext:
            QMessageBox.information(self, "Extensões", "Somente extensões externas podem ser removidas.")
            return

        res = QMessageBox.question(
            self,
            "Remover extensão",
            f"Remover a extensão:\n\n{it.text()}",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if res != QMessageBox.Yes:
            return

        try:
            remove_external_parser(pid)
        except Exception as e:
            QMessageBox.critical(self, "Extensões", f"Falha ao remover:\n\n{e}")

        self._reload_parsers_list()
