APP_NAME = "SekaiTranslatorV"
APP_VERSION = "0.1.2"
UPDATE_OWNER = "Satonix"
UPDATE_REPO = "SekaiTranslatorV"
