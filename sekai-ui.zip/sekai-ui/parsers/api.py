from __future__ import annotations

from typing import Any, Optional
import os
import shutil

from .manager import ParserManager
from .repository import (
    RepoSpec,
    install_or_update_repo as _install_or_update_repo,
    remove_repo,
    repo_status,
    list_repo_parsers,
)


DEFAULT_REPO_URL = "https://github.com/Satonix/SekaiTranslatorV"
DEFAULT_BRANCH = "main"


def _default_spec() -> RepoSpec:
    return RepoSpec(repo_url=DEFAULT_REPO_URL, branch=DEFAULT_BRANCH)


def list_parsers() -> dict[str, Any]:
    pm = ParserManager()
    status = repo_status()
    repo_installed = bool(status.get("installed", False))
    repo_info = list_repo_parsers() if repo_installed else []
    return {
        "repo_installed": repo_installed,
        "installed": [p.as_dict() for p in pm.registry.all()],
        "repo": repo_info,
    }


def install_or_update_repo(spec: Optional[RepoSpec] = None) -> dict[str, Any]:
    # Compat: callers may call without args.
    return _install_or_update_repo(spec or _default_spec())


def install_or_update_repo_default() -> dict[str, Any]:
    return _install_or_update_repo(_default_spec())


def uninstall_repo() -> None:
    remove_repo()


def remove_external_parser(plugin_id: str) -> None:
    # Remove a parser installed in the external parsers folder by plugin_id
    pm = ParserManager()
    reg = pm.registry.get(plugin_id)
    if not reg:
        return
    folder = getattr(reg, "folder", "") or ""
    if folder and os.path.isdir(folder):
        shutil.rmtree(folder, ignore_errors=True)
